﻿namespace xServer.Core.Data
{
    public static class Messagebox
    {
        public static string Caption { get; set; }
        public static string Text { get; set; }
        public static string Button { get; set; }
        public static string Icon { get; set; }
    }
}

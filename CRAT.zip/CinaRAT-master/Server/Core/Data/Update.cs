﻿namespace xServer.Core.Data
{
    public static class Update
    {
        public static bool UseDownload { get; set; }
        public static string UploadPath { get; set; }
        public static string DownloadURL { get; set; }
    }
}

﻿namespace xServer.Enums
{
    public enum ShutdownAction
    {
        Shutdown,
        Restart,
        Standby
    }
}
